public class SequenceManager {

    // Método para obter o próximo valor de uma sequência
    public static int getValue(Connection conn, String sequenceName) throws SQLException {
        String sql = "SELECT NEXT VALUE FOR " + sequenceName;
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            } else {
                throw new SQLException("Não foi possível obter o próximo valor da sequência.");
            }
        }
    }
}
